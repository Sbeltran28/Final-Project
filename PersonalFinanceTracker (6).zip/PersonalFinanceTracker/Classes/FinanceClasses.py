from os.path import exists

# The Budget class holds 4 properties that correspond to the user information
# that the user provides. This class also houses two methods that are called
# from the Main.py file based on the user's UI interactions. 
class Budget(object):

    def __init__(self, target, income, expenses, savings):
        self.Target = Target(target, [])
        self.Income = Income(income, [])
        self.Expenses = Expenses(expenses, [])
        self.Savings = Savings(savings, [])
        
    def ModifyEntry(self, entryType, value):
        try:
            float(value)
        except:
            raise Exception('Value provided was not a number or the entry was empty. Please only use numerical values')
        
        if entryType == "target":
            self.Target.Total = value
            self.Target.History.append(value)
        elif entryType == "income":
            self.Income.Total = value
            self.Income.History.append(value)
        elif entryType == "expenses":
            self.Expenses.Total = value
            self.Expenses.History.append(value)
        elif entryType == "savings":
            self.Savings.Total = value
            self.Savings.History.append(value)

# The user can view all previously made updates in the Update Log section of the
# text file. 
    def GetHistoryText(self):
        elements = (self.Target, self.Income, self.Expenses, self.Savings)
        text = ""

        for element in elements:
            text += element.GetHistoryText()

        return text
            
    
    def PrintSummaryAsTextFile(self):
        filePath = 'summary.txt'
        fileExists = exists(filePath)

        summaryText = "Print Summary:\n" + \
        "Your budget for this month is: " + str(self.Target.Total) + "\n" + \
        "Your income for this month is: " + str(self.Income.Total) + "\n" + \
        "Your expenses for this month are: " + str(self.Expenses.Total) + "\n" + \
        "Your savings for this month are: " + str(self.Savings.Total)

        historyText = "\nUpdate Log: " + self.GetHistoryText()

        allText = summaryText + historyText
        
        if not fileExists:
            f = open(filePath, "x")
            f.write(allText)
        else:
            f = open(filePath, "w")
            f.write(allText)
                  

# The Entry class is the parent class to the four subclasses underneath. 
class Entry(object):
    def __init__(self, total, history):
        self.Total = total
        self.History = history

    def GetHistoryText(self):
        text = ""
        for change in self.History:
            text += str(change) + ","
        return text

        
class Target(Entry):
    def __init__(self, total, history):
        super().__init__(total, history)
        
class Income(Entry):
    def __init__(self, total, history):
        super().__init__(total, history)
        

class Expenses(Entry):
    def __init__(self, total, history):
        super().__init__(total, history)
        

class Savings(Entry):
    def __init__(self, total, history):
        super().__init__(total, history)
