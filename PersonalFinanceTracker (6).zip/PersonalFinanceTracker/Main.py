from Classes.FinanceClasses import *
import tkinter as tk

# Initializes budget properties as zero and then instantiates a budget object. 
target = 0
income = 0
expenses = 0
savings = 0

budget = Budget(target, income,expenses,savings)

def UpdateEntry(entryType, value):
    budget.ModifyEntry(entryType, value)

def PrintSummary():
    budget.PrintSummaryAsTextFile()


# Creates the UI Window including various labels and buttons to prompt the user to
# fill in and update the financial information. The UI components are packed after
# they are configured. In this case, we have four entries and 5 buttons.
app = tk.Tk()
app.geometry("400x600")

welcomeLabel = tk.Label(app, text='''Please input your financial information below and click on Update.
                        \nClick on Print Summary below to print your financial summary\n ''')
welcomeLabel.pack()

targetLabel = tk.Label(app, text="What is your budget for the month?")
targetInput = tk.Entry(app)
targetUpdateButton = tk.Button(app, text="Update", command= lambda: UpdateEntry("target", targetInput.get()))
targetLabel.pack()
targetInput.pack()
targetUpdateButton.pack()

# These space labels add space between the UI elements to improve UI readability. 
spaceLabel = tk.Label(app, text='''\n \n''')
spaceLabel.pack()

incomeLabel = tk.Label(app, text="Monthly Income:")
incomeInput = tk.Entry(app)
incomeUpdateButton = tk.Button(app, text="Update", command= lambda: UpdateEntry("income", incomeInput.get()))
incomeLabel.pack()
incomeInput.pack()
incomeUpdateButton.pack()

spaceLabel = tk.Label(app, text='''\n \n''')
spaceLabel.pack()

expensesLabel = tk.Label(app, text="Monthly Expenses:")
expensesInput = tk.Entry(app)
expensesUpdateButton = tk.Button(app, text="Update", command= lambda: UpdateEntry("expenses", expensesInput.get()))
expensesLabel.pack()
expensesInput.pack()
expensesUpdateButton.pack()

spaceLabel = tk.Label(app, text='''\n \n''')
spaceLabel.pack()

savingsLabel = tk.Label(app, text="Savings:")
savingsInput = tk.Entry(app)
savingsUpdateButton = tk.Button(app, text="Update", command= lambda: UpdateEntry("savings", savingsInput.get()))
savingsLabel.pack()
savingsInput.pack()
savingsUpdateButton.pack()

spaceLabel = tk.Label(app, text='''\n \n''')
spaceLabel.pack()

printLabel = tk.Label(app, text="Print Financial Summary")
printButton = tk.Button(app, text="Print", command=PrintSummary)
printLabel.pack()
printButton.pack()

app.mainloop()
